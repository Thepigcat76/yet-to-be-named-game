import pygame

pygame.init()

print(pygame.font.get_fonts())
