blacklisted-keys:
    All arrow keys
    Tab (must skip 4-times as much as space)
    Shift-keys
    Strg/ctrl
    alt
    alt-gr
    